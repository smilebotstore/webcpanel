
const YOUR_MEMID = "#";
const YOUR_KEYORKUT = "#";
const YOUR_QR_CODE = "#";
const domain = 'https://#';
const apikey = '#';
const GITHUB_TOKEN = '#';
const REPO_OWNER = '#';
const REPO_NAME = '#';
const FILE_PATH = 'system/panel.json'

module.exports = {
    YOUR_MEMID,
    YOUR_KEYORKUT,
    YOUR_QR_CODE,
    domain,
    apikey,
    GITHUB_TOKEN,
    REPO_OWNER,
    REPO_NAME,
    FILE_PATH
};